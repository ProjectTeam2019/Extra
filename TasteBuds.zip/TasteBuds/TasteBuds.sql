-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 01, 2019 at 12:04 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `TasteBuds`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` varchar(10) NOT NULL,
  `cat_name` varchar(10) NOT NULL,
  `cat_img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_img`) VALUES
('Cat1', 'Breakfast', 'bf1.jpeg'),
('Cat2', 'Brunch', 'brunch1.jpg'),
('Cat3', 'Lunch', 'lunch1.jpg'),
('Cat4', 'Dinner', 'dinner1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `KitchenTips`
--

CREATE TABLE `KitchenTips` (
  `tips_id` varchar(10) NOT NULL,
  `tips` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `KitchenTips`
--

INSERT INTO `KitchenTips` (`tips_id`, `tips`) VALUES
('tips1', 'Add lemon after cooking in dish otherwise it will release its bitter taste.'),
('tips2', 'Wrap plastic sheet on the tops of the banana to prevent it from getting spoiled.');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `user_id` varchar(10) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `user_profile` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`user_id`, `user_name`, `email`, `password`, `user_profile`) VALUES
('27ZOhMTjbo', 'Shreya', 'Shreya@gmail.com', 'U2hyZXlhQDE=', 'defaultProfile.png'),
('6GiYIdwiJA', 'Krima', 'Krima@gmail.com', 'S3JpbWFANw==', 'defaultProfile.png'),
('CnzZHOFS2f', 'Mansi', 'Mansi@gmail.com', 'TWFuc2lAMjI=', 'defaultProfile.png'),
('Pz8fCUqWun', 'Ronit ', 'Ronit@gmail.com', 'Um9uaXRAMTI=', 'defaultProfile.png'),
('UWnzNcGpiJ', 'Maitri', 'Maitri@yahoo.com', 'TWFpdHJpQDk=', 'defaultProfile.png');

-- --------------------------------------------------------

--
-- Table structure for table `shopping_list`
--

CREATE TABLE `shopping_list` (
  `shop_list_id` varchar(10) NOT NULL,
  `shop_list_ing` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shopping_list`
--

INSERT INTO `shopping_list` (`shop_list_id`, `shop_list_ing`) VALUES
('shop1', 'chily,turmeric,cream,noodles'),
('shop2', 'apple,brocoli,zucini,lettuce');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
