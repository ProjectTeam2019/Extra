
import UIKit

class BrunchRecipes: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()

    }
}
