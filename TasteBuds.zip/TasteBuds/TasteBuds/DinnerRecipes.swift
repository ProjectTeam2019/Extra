

import UIKit

class DinnerRecipes: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()

    }
}
