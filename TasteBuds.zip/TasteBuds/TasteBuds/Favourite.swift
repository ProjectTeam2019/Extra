
import UIKit
import SkyFloatingLabelTextField
import GoogleSignIn

class Favourite: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    @IBOutlet weak var favtbl: UITableView!
    var arr = ["back2","back2.png"]
    var lblarr = ["iOS","mac"]
    
    let objNav = NavigationBar()
    
    var userBarItem = UIBarButtonItem()
    var searchBarItem = UIBarButtonItem()
    var sideBarItem = UIBarButtonItem()
    
    let userBtn = UIButton(type: .custom)
    let searchBtn = UIButton(type: .custom)
    let sideBtn = UIButton(type: .custom)
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        let nav = navigationController
        nav?.isNavigationBarHidden = true
        print("okk")
        navigationItems()
        fetch()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! favcell
        cell.img.image = UIImage(named: arr[indexPath.row])
        cell.lblresp.text! = lblarr[indexPath.row]
        print(arr.count)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 271.0
    }
    
    func fetch()
    {
        let url = URL(string: "http://localhost/WebServices/FavouritesGet.php");
        let request = URLRequest(url: url!);
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request)
        {
            (data1, resp, err) in
            let strrep = String(data: data1!, encoding: String.Encoding.utf8)
            print(strrep as Any)
            do
            {
                
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]];
                print(jsondata)
               // self.idata = jsondata
              //  print(self.idata)
                DispatchQueue.main.async
                    {
                        self.favtbl.reloadData()
                }
                
            }
            catch{}
        }
        datatask.resume()
    }
    
    func navigationItems()
    {
        let navbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
        let navitem = UINavigationItem(title: "FAVOURITES")
        
        userBarItem = objNav.createNavItem(btn: userBtn, image: "usericon.png", btnFrame: CGRect(x: self.view.frame.size.width - 30, y: 0, width: 30, height: 30))
        searchBarItem = objNav.createNavItem(btn: searchBtn, image: "searchicon.png", btnFrame: CGRect(x: self.view.frame.size.width - 53, y: 0, width: 53, height: 30))
        sideBarItem = objNav.createNavItem(btn: sideBtn, image: "sidebar.png", btnFrame: CGRect(x: 0, y: 0, width: 30, height: 30))
        
        userBtn.addTarget(self, action: #selector(self.userAction), for: .touchUpInside)
        searchBtn.addTarget(self, action: #selector(self.searchAction), for: .touchUpInside)
        sideBtn.addTarget(self, action: #selector(self.sidebarAction), for: .touchUpInside)
        
        
        let arr = [userBarItem,searchBarItem]
        
        navitem.leftBarButtonItem = sideBarItem
        navitem.rightBarButtonItems = arr
        navbar.items = [navitem]
        self.view.addSubview(navbar)
    }
    
    @objc func sidebarAction()
    {
        print("sidebar")
    }
    
    @objc func searchAction()
    {
        print("search")
    }
    
    @objc func userAction()
    {
        let alt = UIAlertController(title: "ALERT", message: "ARE YOU SURE TO LOGOUT", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default) { (ACTION) in
            
            let dif = UserDefaults.standard
            dif.removeObject(forKey: "uname")
            
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
            self.navigationController?.pushViewController(stb!, animated: true)
            GIDSignIn.sharedInstance().signOut()
            
        }
        
        let cancel = UIAlertAction(title: "CANCEL", style: .destructive, handler: nil)
        alt.addAction(ok)
        alt.addAction(cancel)
        self.present(alt, animated: true, completion: nil)
    }
}
