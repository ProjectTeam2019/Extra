
import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class GroceryList: UIViewController,UITabBarDelegate,UITableViewDelegate,UITableViewDataSource
{
    var idata : [[String:String]] = [[:]]
    var  dic : [String:String] = [:]

    var barView = UIView()
    @IBOutlet weak var groceryView: UIView!
    
    @IBOutlet weak var shoptbl: UITableView!
    let objNav = NavigationBar()
    var cont = Controls()
    
    var table = UITableView()
    var add = TransitionButton()
    var searchRec = SkyFloatingLabelTextField()
    var addBtn = UIButton(type: .custom)
    var cancelBtn = UIButton(type: .custom)
    
    var navbar = UINavigationBar()
    var navsearchbar = UINavigationBar()
    var searchBarItem = UIBarButtonItem()
    var sideBarItem = UIBarButtonItem()
    var backItem = UIBarButtonItem()
    
    let searchBtn = UIButton(type: .custom)
    let sideBtn = UIButton(type: .custom)
    let backBtn = UIButton(type: .custom)
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        
        addText()
        addButton()
        navigationItems()
        
        let url = URL(string: "http://localhost/WebServices/ShoplistGet.php");
        let request = URLRequest(url: url!);
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request)
        {
            (data1, resp, err) in
            let strrep = String(data: data1!, encoding: String.Encoding.utf8)
            print(strrep as Any)
              do
              {
                    let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]];
                    self.idata = jsondata as! [[String : String]]
                    print(self.idata)
                    DispatchQueue.main.async
                    {
                        self.shoptbl.reloadData()
                    }
              }
             catch{}
        }
        datatask.resume()
    }
    
    func tableCreation()
    {
        table = UITableView(frame: CGRect(x: 0, y: 130, width: self.groceryView.frame.size.width, height: 50), style: .grouped)
        table.dataSource = self
        table.delegate = self
        self.groceryView.addSubview(table)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return idata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! GroceryTableViewCell
        dic = idata[indexPath.row]
        print(indexPath.row)
        cell.textLabel?.text = dic["shop_list_ing"]
        let com = dic["shop_list_ing"]
        print(com!)

        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        idata.remove(at: indexPath.row)
        tableView.reloadData()
    }
    
    func navigationItems()
    {
        navbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
        let navitem = UINavigationItem(title: "GROCERY LIST")
        
       
        searchBarItem = objNav.createNavItem(btn: searchBtn, image: "searchicon.png", btnFrame: CGRect(x: self.view.frame.size.width - 53, y: 0, width: 53, height: 30))
        sideBarItem = objNav.createNavItem(btn: sideBtn, image: "sidebar.png", btnFrame: CGRect(x: 0, y: 0, width: 30, height: 30))
        
        searchBtn.addTarget(self, action: #selector(self.searchAction), for: .touchUpInside)
        sideBtn.addTarget(self, action: #selector(self.sidebarAction), for: .touchUpInside)

        navitem.leftBarButtonItem = sideBarItem
        navitem.rightBarButtonItem = searchBarItem
        navbar.items = [navitem]
        self.view.addSubview(navbar)
    }
    
    @objc func sidebarAction()
    {
        print("sidebar")
    }
    
    @objc func searchAction()
    {
        print("search")
        
        let src = UISearchBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))

        self.view.addSubview(src)
    }
        
      /*  navsearchitems()
        searchRec = cont.customtext(frame: CGRect(x: 53, y: 0, width: 237, height: 40), placeholder: "Search Ingredient", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "", selTitleCol: UIColor.blue, secure: false)
        self.navsearchbar.addSubview(searchRec)
    
    func navsearchitems()
    {
        let navitem = UINavigationItem()
        navsearchbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
         backItem = objNav.createNavItem(btn: backBtn, image: "back2.png", btnFrame: CGRect(x: 0, y: 0, width: 30, height: 30))
        backBtn.addTarget(self, action: #selector(self.back), for: .touchUpInside)
        navitem.leftBarButtonItem = backItem
        navsearchbar.items = [navitem]
        self.view.addSubview(navsearchbar)
    }*/
    
    @objc func back()
    {
        navigationItems()
    }
    
    func addText()
    {
        searchRec = cont.customtext(frame: CGRect(x: 20, y: 70, width: 245, height: 40), placeholder: "Ingredient", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Add Ingredient", selTitleCol: UIColor.blue, secure: false)
        self.groceryView.addSubview(searchRec)
    }
    func addButton()
    {
        let Addimg = UIImage(named: "add1.png")
        addBtn.frame = CGRect(x: 280, y: 90, width: 50, height: 30)
        addBtn.setImage(Addimg, for: .normal)
        addBtn.addTarget(self, action: #selector(self.addBtnAction), for: .touchUpInside)
        self.groceryView.addSubview(addBtn)
        
        let Cancelimg = UIImage(named: "delete.png")
        cancelBtn.frame = CGRect(x: 320, y: 90, width: 50, height: 30)
        cancelBtn.setImage(Cancelimg, for: .normal)
        cancelBtn.addTarget(self, action: #selector(self.cancelBtnAction), for: .touchUpInside)
        self.groceryView.addSubview(cancelBtn)
    }
    
    @objc func addBtnAction()
    {
        print("Add")
    }
    @objc func cancelBtnAction()
    {
        print("Cancel")
    }
}
