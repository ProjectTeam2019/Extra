
import UIKit

class JsonGet: NSObject
{
    var idata : [[String:String]] = [[:]]
    func getdata(url : URL,tbl : UITableView)
    {
        let request = URLRequest(url: url);
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request)
        {
            (data1, resp, err) in
            //let strrep = String(data: data1!, encoding: String.Encoding.utf8)
            //print(strrep as Any)
            
                DispatchQueue.main.async
                {
                    do
                    {
                        let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]];
                        self.idata = jsondata as! [[String : String]]
                        tbl.reloadData()
                        print(self.idata)
                    }
                    catch{}
                }
        }
        datatask.resume()

    }
    
}
