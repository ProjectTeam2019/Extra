
import UIKit

class KitchenTips: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    @IBOutlet weak var tblTips: UITableView!
    var objCancel = CancelBtn()
    var objJson = JsonGet()
    
    var btn = UIButton()
    var idata : [[String:String]] = [[:]]
    var dic : [String:String] = [:]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        btncancel()
        get()
    }
    
    func btncancel()
    {
        btn = objCancel.btncancel()
        btn.addTarget(self, action: #selector(self.test), for: .touchDown)
        self.view.addSubview(btn)
    }
    
    @objc func test(sender:UIButton)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    
    func get()
    {
        let url = URL(string: "http://localhost/WebServices/KitchenTipsGet.php")
        let request = URLRequest(url: url!);
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request)
        {
            (data1, resp, err) in
            //let strrep = String(data: data1!, encoding: String.Encoding.utf8)
            //print(strrep as Any)
            do
            {
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]];
                self.idata = jsondata as! [[String : String]]
                print(self.idata)
                DispatchQueue.main.async
                    {
                        self.tblTips.reloadData()
                }
            }
            catch{}
        }
        datatask.resume()
        //idata = objJson.getdata(url: url!, tbl: tblTips)
        //print(idata)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return idata.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TipsCell
        dic = idata[indexPath.row]
        print(indexPath.row)
        cell.txtView.text = dic["tips"]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
    }
}
