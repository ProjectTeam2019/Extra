
import UIKit

class LunchRecipes: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()

    
    }
}
