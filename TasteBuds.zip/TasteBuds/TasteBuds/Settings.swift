
import UIKit

class Settings: UIViewController
{
    var objCancel = CancelBtn()
    var btn = UIButton()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        let nav = navigationController
        nav?.isNavigationBarHidden = true
        btncancel()
    }
    
    func btncancel()
    {
        btn = objCancel.btncancel()
        btn.addTarget(self, action: #selector(self.test), for: .touchDown)
        self.view.addSubview(btn)
    }
    
    @objc func test(sender:UIButton)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
}
