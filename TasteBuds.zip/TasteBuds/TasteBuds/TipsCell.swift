
import UIKit

class TipsCell: UITableViewCell
{

    @IBOutlet weak var txtView: UITextView!
    override func awakeFromNib()
    {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        
    }

}
