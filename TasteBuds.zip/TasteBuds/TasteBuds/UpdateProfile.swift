
import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class UpdateProfile: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate
{
    @IBOutlet weak var profileBtn: UIButton!
    @IBOutlet weak var profile: UIImageView!
    let cont = Controls()
    
    var name = SkyFloatingLabelTextField()
    var password = SkyFloatingLabelTextField()
    var email = SkyFloatingLabelTextField()
    var update = TransitionButton()
    
    var objCancel = CancelBtn()
    var btn = UIButton()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        
        profileBtn.layer.cornerRadius = 30
        profileBtn.clipsToBounds = true
        profile.layer.cornerRadius = 70
        profile.clipsToBounds = true
        profileBtn.backgroundColor = UIColor.lightGray
        
        btncancel()
        txtField()
        btnUpdate()
    }
    
    func btncancel()
    {
        btn = objCancel.btncancel()
        btn.addTarget(self, action: #selector(self.test), for: .touchDown)
        self.view.addSubview(btn)
    }
    @objc func test(sender:UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnProfileAction(_ sender: Any)
    {
        let option = UIAlertController(title: "", message: "", preferredStyle: .actionSheet)
        
        let capture = UIAlertAction(title: "CAPTURE PHOTO", style: .default)
        { (ACTION) in
            let pickImg = UIImagePickerController()
            pickImg.sourceType = .camera
            pickImg.delegate = self as! UIImagePickerControllerDelegate & UINavigationControllerDelegate
            pickImg.cameraDevice = .rear
            self.present(pickImg, animated: true, completion: nil)
        }
        
        
        let delete = UIAlertAction(title: "DELETE PHOTO", style: .default)
        { (ACTION) in
            self.profile.image = UIImage(named: "defaultProfile.png")
        }
        
        
        let photoLib = UIAlertAction(title: "CHOOSE PHOTO", style: .default)
        { (ACTION) in
            let pickImg = UIImagePickerController()
            pickImg.sourceType = .photoLibrary
            pickImg.delegate = self as! UIImagePickerControllerDelegate & UINavigationControllerDelegate
            self.present(pickImg, animated: true, completion: nil)
        }
        
        let cancel = UIAlertAction(title: "CANCEL", style: .destructive, handler: nil)
        option.addAction(photoLib)
        option.addAction(capture)
        option.addAction(delete)
        option.addAction(cancel)
        self.present(option, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        let profileImg = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        profile.image = profileImg
        self.dismiss(animated: true, completion: nil)
    }
    
    func txtField()
    {
        name = cont.customtext(frame: CGRect(x: 80, y: 240, width: 237, height: 50), placeholder: "Username", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Change Username", selTitleCol: UIColor.blue, secure: false)
        name.addTarget(self, action: #selector(self.actName), for: .editingChanged)
        self.view.addSubview(name)
        
        password = cont.customtext(frame: CGRect(x: 80, y: 320, width: 237, height: 50), placeholder: "Password", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Change Password", selTitleCol: UIColor.blue, secure: false)
        password.addTarget(self, action: #selector(self.actPass), for: .editingChanged)
        self.view.addSubview(password)
        
        email = cont.customtext(frame: CGRect(x: 80, y: 400, width: 237, height: 50), placeholder: "Email", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Change Email", selTitleCol: UIColor.blue, secure: false)
        email.addTarget(self, action: #selector(self.actEmail), for: .editingChanged)
        self.view.addSubview(email)
    }
    
    func btnUpdate()
    {
        update = cont.custombutton(frame: CGRect(x: 60, y: 500, width: 270, height: 40), bgcolor: UIColor.gray, title: "Update Profile", radius: 20, spicolor: UIColor.white)
        update.addTarget(self, action: #selector(self.actUpdate), for: .touchUpInside)
        self.view.addSubview(update)
    }
    
    @objc func actUpdate()
    {
        update.startAnimation()
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute:
            {
                sleep(3)
                DispatchQueue.main.async(execute:
                    { () -> Void in
                        self.update.stopAnimation(animationStyle: .expand, completion:
                            {
                                let secondVC = UIViewController()
                                self.present(secondVC, animated: true, completion: nil)
                        })
                })
        })
    }
    
    @objc func actName()
    {
        
    }
    @objc func actPass()
    {
        
    }
    @objc func actEmail()
    {
        
    }
}
