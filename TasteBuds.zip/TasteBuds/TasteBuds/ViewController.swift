

import UIKit

class ViewController: UIViewController {

    
    var time = Timer()

    override func viewDidLoad()
    {
        
        super.viewDidLoad()
        let nav = navigationController
        nav?.isNavigationBarHidden = true
    
        time = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(self.move), userInfo: nil, repeats: true)
        
    }
    
    @objc func move(sender:Timer)
    {
            time.invalidate()
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "skip")
            self.navigationController?.pushViewController(stb!, animated: true)
        //self.navigationController?.popToViewController((self.navigationController?.viewControllers[1])!, animated: true)
        
    }


}

