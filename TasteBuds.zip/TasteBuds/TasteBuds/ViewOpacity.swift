
import UIKit

class ViewOpacity: NSObject
{

    func viewOp(vw : UIView)
    {
        vw.layer.masksToBounds = false
        vw.layer.shadowOffset = CGSize(width: 2, height: 2)
        vw.layer.shadowOpacity = 0.8
        vw.layer.opacity = 0.8
    }
}
