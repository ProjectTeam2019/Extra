
import UIKit
import TransitionButton

class skip: UIViewController {

    @IBOutlet weak var skipview: UIView!
    
    var cont = Controls()
    var login = TransitionButton()
    var reg = TransitionButton()
    let objView = ViewOpacity()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.skipview.layer.cornerRadius = 10
        objView.viewOp(vw: skipview)
        
        addBtn()
        
    }
    
    
    @IBAction func btnlater(_ sender: Any)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    
    
    @IBAction func privacy(_ sender: Any)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "privacy")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    func addBtn()
    {
        login = cont.custombutton(frame: CGRect(x: 80, y: 50, width: 220, height: 30), bgcolor: UIColor.darkGray, title: "GET IN", radius: 20, spicolor: UIColor.white)
        login.addTarget(self, action: #selector(self.btnLogin), for: .touchUpInside)
        self.skipview.addSubview(login)
        
        
        reg = cont.custombutton(frame: CGRect(x: 80, y: 110, width: 220, height: 30), bgcolor: UIColor.darkGray, title: "INSCRIBE", radius: 20, spicolor: UIColor.white)
        
        reg.addTarget(self, action: #selector(self.btnReg), for: .touchUpInside)
        self.skipview.addSubview(reg)
        
    }

    @objc func btnLogin()
    {
        login.startAnimation()
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute:
            {
                sleep(3)
                DispatchQueue.main.async(execute:
                    { () -> Void in
                        self.login.stopAnimation(animationStyle: .expand, completion:
                            {
                                let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
                                self.navigationController?.pushViewController(stb!, animated: true)
                        })
                })
        })
    
                                
    }
    
    
    @objc func btnReg()
    {
        reg.startAnimation()
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute:
            {
                sleep(3)
                DispatchQueue.main.async(execute:
                    { () -> Void in
                        self.reg.stopAnimation(animationStyle: .expand, completion:
                            {
                                let stb = self.storyboard?.instantiateViewController(withIdentifier: "register")
                                self.navigationController?.pushViewController(stb!, animated: true)
                        })
                })
        })
        
        
    }

}
