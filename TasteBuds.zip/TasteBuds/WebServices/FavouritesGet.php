<?php
$cn = new mysqli("localhost","root","","TasteBuds");
//$email=$_REQUEST["email"];
    $q = mysqli_query($cn,"select * from favourites");// where email='$email' and password='$password'");
if (mysqli_num_rows($q)==0) 
{	
	$row = array();
	print_r(json_encode($row));
}
else
{
	while ($row=mysqli_fetch_assoc($q))
    {
		$pp[]=$row;
	}
	echo json_encode($pp);
}
?>
