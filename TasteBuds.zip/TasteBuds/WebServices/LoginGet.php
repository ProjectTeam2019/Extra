<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$email=$_REQUEST["email"];
$password=base64_encode($_REQUEST["password"]);
$qr="select * from register where email='$email' and password='$password'";
$q = mysqli_query($cn,$qr);
if (mysqli_num_rows($q)==0)
{	
	$row = array();
	print_r(json_encode($row));
}
else
{
	while ($row=mysqli_fetch_assoc($q	))
    {
		$pp[]=$row;
	}
	echo json_encode($pp);
}
?>
