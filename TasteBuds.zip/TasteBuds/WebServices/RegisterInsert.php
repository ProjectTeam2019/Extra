<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$data = file_get_contents('php://input');
$dt = json_decode($data);
$user_name = $dt->user_name;
$email = $dt->email;
$password = base64_encode($dt->password);
$user_profile = "defaultProfile.png";
function generateRandomString($length = 10)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++)
    {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$user_id = generateRandomString();
$query = "insert into register(user_id,user_name,email,password,user_profile) values('$user_id','$user_name','$email','$password','$user_profile')";
$cn->query($query);
echo "Successful";
?>
