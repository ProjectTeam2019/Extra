<?php
   $cn = new mysqli("localhost","root","","TasteBuds");
    $qr = "select * from shopping_list";
    $q = mysqli_query($cn,$qr);
    if(mysqli_num_rows($q)==0)
    {
        $row = array();
        print_r(json_encode($row));
    }
    else
    {
        while ($row=mysqli_fetch_assoc($q))
        {
            $pp[]=$row;
        }
        echo json_encode($pp);
        /*foreach($pp as $key){
            $list=explode(",",$key['shop_list_ing']);
            foreach($list as $k)
            {
                echo  $k."</br>";
                
            }
            
        }*/
    }
?>



