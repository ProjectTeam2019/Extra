<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$data = file_get_contents('php://input');
$dt  =  json_decode($data);
$category_name = $dt->category_name;
$category_image = $dt->category_image;
$query = "insert into category(category_name,category_image) values('$category_name','$category_image')";
$cn->query($query);
echo "Successful";
?>
